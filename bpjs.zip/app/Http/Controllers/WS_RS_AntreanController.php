<?php


namespace App\Http\Controllers;

use Purnama97;
use App\Libraries\Helpers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\JadwalDokter;
use Carbon\Carbon;

class WS_RS_AntreanController extends Controller
{
    public function __construct(Request $request)
    {
        $this->request = $request;
        // $this->name = $this->request->auth['Credentials']->name;
    }

    public function connection()
    {
        //use your own bpjs config
        // $data = DB::table("rs_bpjs_config")->get();
        $vclaim_conf = [
            'cons_id' => env('CONS_ID_BPJS'),
            'secret_key' => env('SECRET_KEY_BPJS'),
            'base_url' => env('BASE_URL_BPJS'),
            'user_key' => env('USER_KEY_BPJS'),
            'service_name' => env('SERVICE_NAME_ANTREAN'),
        ];

        return $vclaim_conf;
    }

    public function get_struk_no()
    {
        {
            $datenow            = Carbon::now();
            $monthNow           = $datenow->month;
            $yearNow            = $datenow->year;
            $dayNow             = $datenow->day;
            $date               = $datenow->toDateString();
    
            $num                = DB::table('rs_counter_antrian')->where('bookingDate', $date)->max('kodeBooking');
            if ($num == 0 || $num == null) {
                $result = intval($yearNow . $monthNow . $dayNow  . sprintf('%05s', 1));
            } else {
                $result = intval($num + 1);
            }
    
            return response()->json([
                "strukNo" => $result,
                "acknowledge" => 1,
                "message"    => 'True!.'
            ], 200);
        }
    }

    public function getStatus()
    {
			try {
				$kodepoli = $this->request->input('kodepoli');
				$kodedokter = $this->request->input('kodedokter');
				$tanggalperiksa = $this->request->input('tanggalperiksa');
				$jampraktek = $this->request->input('jampraktek');

				$jampraktek = explode('-', $jampraktek);


				
				$data = JadwalDokter::where('poli_id', $kodepoli)
							->where('dokter_id', $kodedokter)
							->where('buka', $jampraktek[0])
							->where('tutup', $jampraktek[1])
							// ->where('jampraktek', $jampraktek)
							->first();

				if($data) {   
					return response()->json([
						"metadata" => [
							"code" => 200,
							"message" => "Ok"
						],
						'response'  => [
							"namapoli" => "Anak",
							"namadokter" =>  "Dr. Hendra",
							"totalantrean" =>  25,
							"sisaantrean" =>  4,
							"antreanpanggil" =>  "A-21",
							"sisakuotajkn" =>  5,
							"kuotajkn" =>  30,
							"sisakuotanonjkn" =>  5,
							"kuotanonjkn" =>  30,
							"keterangan" =>  $this->get_struk_no()->getData()->strukNo
						]
					], 200);
				}else{
						return response()->json([
								'metadata'    => [
										"code" => 201,
										"message" => "Gagal"
								],
								'response'        => "Gagal mengecek status!."
						], 200);
				}
			} catch (\Throwable $e) {
				return response()->json([
					'acknowledge' => 0,
					'error_message' => $e->getMessage(),
					'error_Line' => $e->getLine(),
					'message'     => "Gagal!."
				], 500);
			}
    }

    public function getAntrian()
    {
        try {
            $dateNow = Carbon::now();
            $nomorkartu = $this->request->input('nomorkartu');
            $nik = $this->request->input('nik');
            $nohp = $this->request->input('nohp');
            $kodepoli = $this->request->input('kodepoli');
            $norm = $this->request->input('norm');
            $tanggalperiksa = $this->request->input('tanggalperiksa');
            $kodedokter = $this->request->input('kodedokter');
            $jampraktek = $this->request->input('jampraktek');
            $jeniskunjungan = $this->request->input('jeniskunjungan');
            $nomorreferensi = $this->request->input('nomorreferensi');

            $request = [
                "kodeBooking" => $this->get_struk_no()->getData()->strukNo,
                "kodePoli" => $kodepoli,
                "kodeDokter" => $kodedokter,
                "noKartu" => $nomorkartu,
                "nik" => $nik,
                "noRm" => $norm,
                "noHp" => $nohp,
                "nomorAntrian" => 0,
                "angkaAntrean" => 0,
                "isJkn" => 1,
                "bookingDate" => $dateNow->toDateString(),
                "jamPraktek" => $jampraktek,
                "noReferensi" => $nomorreferensi,
                "jenisKunjungan" => $jeniskunjungan,
                "isCall" => 0,
                "createdAt" => $dateNow->toDateTimeString(),
                "updatedAt" => $dateNow->toDateTimeString()
            ];

            $jampraktek = $this->request->input('jampraktek');
            $jampraktek = explode('-', $jampraktek);
            
            $data = JadwalDokter::where('poli_id', $kodepoli)
                        ->where('dokter_id', $kodedokter)
                        ->where('buka', $jampraktek[0])
                        ->where('tutup', $jampraktek[1])
                        // ->where('jampraktek', $jampraktek)
                        ->first();

            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
                "response" => [
                   "nomorantrean" => "A-12",
                   "angkaantrean" => 12,
                   "kodebooking" => "16032021A001",
                   "norm" => "123345",
                   "namapoli" => "Anak",
                   "namadokter" => "Dr. Hendra",
                   "estimasidilayani" => 1615869169000,
                   "sisakuotajkn" => 5,
                   "kuotajkn" => 30,
                   "sisakuotanonjkn" => 5,
                   "kuotanonjkn" => 30,
                   "keterangan" => "Peserta harap 60 menit lebih awal guna pencatatan administrasi."
                ],
                "request" => $request
            ];

            if(sizeof($data["response"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                    'response'        => $data["response"],
                    'request'        => $data["request"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal mengambil antrean!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }

    public function getSisaAntrian()
    {
        try {
            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
                "response" => [
                    "nomorantrean" => "A20",
                    "namapoli" => "Anak",
                    "namadokter" => "Dr. Hendra",
                    "sisaantrean" => 12,
                    "antreanpanggil" => "A-8",
                    "waktutunggu" => 9000,
                    "keterangan" => ""
                ]
            ];

            if(sizeof($data["response"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                    'response'        => $data["response"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal cek sisa antrean!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }

    public function batalAntrian()
    {
        try {
            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
            ];

            if(sizeof($data["metadata"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal membatalkan antrean!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }

    public function checkinAntrian()
    {
        try {
            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
            ];

            if(sizeof($data["metadata"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal Checkin antrean!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }

    public function getInfoPasien()
    {
        try {
            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
                "response"=> [
                    "norm" => "123456"
                ],
            ];

            if(sizeof($data["metadata"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                    'response'    => $data["response"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal memuat info pasien!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }

    public function jadwalOkRS()
    {
        try {
            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
                "response" =>  [
                    "list" => [
                        [
                            "kodebooking" => "123456ZXC",
                            "tanggaloperasi" => "2019-12-11",
                            "jenistindakan" => "operasi gigi",
                            "kodepoli" => "001",
                            "namapoli" => "Poli Bedah Mulut",
                            "terlaksana" => 1,
                            "nopeserta" => "0000000924782",
                            "lastupdate" => 1577417743000 
                        ],
                        [
                            "kodebooking" => "67890QWE",
                            "tanggaloperasi" => "2019-12-11",
                            "jenistindakan" => "operasi mulut",
                            "kodepoli" => "001",
                            "namapoli" => "Poli Bedah Mulut",
                            "terlaksana" => 0,
                            "nopeserta" => "",
                            "lastupdate" => 1577417743000
                        ]
                    ]
                ]
            ];

            if(sizeof($data["metadata"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                    'response'    => $data["response"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal memuat info pasien!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }

    public function jadwalOkPasien()
    {
        try {
            $data = [
                "metadata" => [
                    "code" => 200,
                    "message" => "Ok"
                ],
                "response"=> [
                    "norm" => "123456"
                ],
            ];

            if(sizeof($data["metadata"]) > 0) {   
                return response()->json([
                    'metaData'    => $data["metadata"],
                    'response'    => $data["response"],
                ], 200);
            }else{
                return response()->json([
                    'metaData'    => [
                        "code" => 201,
                        "message" => "Gagal"
                    ],
                    'response'        => "Gagal memuat info pasien!.",
                ], 200);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'acknowledge' => 0,
                'error_message' => $e->getMessage(),
                'error_Line' => $e->getLine(),
                'message'     => "Gagal!."
            ], 500);
        }
    }
}
